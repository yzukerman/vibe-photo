/**
 * Navigation functionality for Vibe Photo Theme using Foundation
 */
(function($) {
    'use strict';

    $(document).ready(function() {
        // Initialize Foundation
        $(document).foundation();
        
        initializeSearchTab();
        initializeSmoothScroll();
        initializeHeaderScroll();
        highlightCurrentPage();
    });

    function initializeSearchTab() {
        // Open search tab when clicking search toggle
        $('.search-toggle').on('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            $('#search-tab').addClass('active');
            $('#search-tab .search-field').focus();
        });

        // Close search tab when clicking anywhere on the page
        $(document).on('click', function(e) {
            if (!$(e.target).closest('#search-tab, .search-toggle').length) {
                $('#search-tab').removeClass('active');
            }
        });

        // Prevent clicks inside the search tab from closing it
        $('#search-tab').on('click', function(e) {
            e.stopPropagation();
        });

        // Close search tab on Escape key
        $(document).on('keydown', function(e) {
            if (e.key === 'Escape' || e.keyCode === 27) {
                $('#search-tab').removeClass('active');
            }
        });
    }

    function initializeSmoothScroll() {
        // Smooth scroll for anchor links
        $('a[href*="#"]:not([href="#"])').on('click', function() {
            if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
                var target = $(this.hash);
                target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
                
                if (target.length) {
                    $('html, body').animate({
                        scrollTop: target.offset().top - 80 // Account for fixed header
                    }, 800);
                    return false;
                }
            }
        });
    }

    function initializeHeaderScroll() {
        var lastScrollTop = 0;
        var header = $('.site-header');
        var headerHeight = header.outerHeight();

        $(window).scroll(function() {
            var scrollTop = $(this).scrollTop();

            // Add/remove scrolled class for styling
            if (scrollTop > 50) {
                header.addClass('scrolled');
            } else {
                header.removeClass('scrolled');
            }

            // Hide/show header on scroll (optional)
            if (scrollTop > lastScrollTop && scrollTop > headerHeight) {
                // Scrolling down
                header.addClass('header-hidden');
            } else {
                // Scrolling up
                header.removeClass('header-hidden');
            }

            lastScrollTop = scrollTop;
        });
    }

    // Add current menu item highlighting
    function highlightCurrentPage() {
        var currentUrl = window.location.href;
        $('.main-navigation a').each(function() {
            if (this.href === currentUrl) {
                $(this).addClass('current-page');
            }
        });
    }

    // Add keyboard navigation support
    $('.main-navigation a').on('keydown', function(e) {
        if (e.which === 13 || e.which === 32) {
            e.preventDefault();
            $(this)[0].click();
        }
    });

    // Foundation is initialized automatically for most components
    // No manual equalizer initialization needed

})(jQuery);
