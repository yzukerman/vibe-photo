<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
	<meta charset="<?php bloginfo('charset'); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php wp_title('|', true, 'right'); ?><?php bloginfo('name'); ?></title>
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
	<?php wp_body_open(); ?>
	<header class="site-header">
		<div class="grid-container">
			<div class="grid-x grid-padding-x align-justify align-middle">
				<div class="cell auto">
					<a href="<?php echo esc_url(home_url()); ?>" class="site-logo">
						<?php bloginfo('name'); ?>
					</a>
				</div>

				<div class="cell shrink">
					<nav class="main-navigation">
						<?php
						wp_nav_menu(array(
							'theme_location' => 'primary',
							'menu_id' => 'primary-menu',
							'container' => false,
							'menu_class' => 'menu horizontal',
							'fallback_cb' => false,
						));
						?>
					</nav>

					<button class="search-toggle" aria-label="Search">
						<span class="search-icon">🔍</span>
					</button>
				</div>
			</div>

			<!-- Search Tab -->
			<div id="search-tab" class="search-tab">
				<div class="grid-container">
					<form role="search" method="get" class="search-form" action="<?php echo esc_url(home_url('/')); ?>">
						<input type="search" class="search-field" placeholder="Search..." value="<?php echo get_search_query(); ?>" name="s" />
					</form>
				</div>
			</div>
		</div>
	</header>