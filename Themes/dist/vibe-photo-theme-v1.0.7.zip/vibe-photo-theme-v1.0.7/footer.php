	<footer class="site-footer">
		<div class="grid-container">
			<div class="grid-x grid-padding-x">
				<div class="cell text-center">
					<p>&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. <?php _e('All rights reserved.', 'vibe-photo'); ?></p>
				</div>
			</div>
		</div>
	</footer>

	<?php wp_footer(); ?>
	</body>

	</html>